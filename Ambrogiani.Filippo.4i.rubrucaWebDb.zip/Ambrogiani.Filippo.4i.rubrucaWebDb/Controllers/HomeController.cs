﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Ambrogiani.Filippo._4i.rubrucaWebDb.Models;

namespace Ambrogiani.Filippo._4i.rubrucaWebDb.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        dbContext db = new dbContext();

        // Se non ci sono record, ne aggiunge uno...
        if (db.Persone.Count() == 0)
        {
            db.Persone.Add(
                new Persona { Nome = "Filippo", Cognome ="Ambrogiani" }
            );
            db.SaveChanges();
        }

        // Passa il db alla view
        return View(db);
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
