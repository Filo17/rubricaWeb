﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Ambrogiani.Filippo._4i.rubrucaWebDb.Models
{
    public class dbContext : DbContext
    {
        private readonly DbContextOptions? _options;
        public dbContext() { }

        protected override void OnConfiguring( DbContextOptionsBuilder options)
                => options.UseSqlite("Data Source=Rubrica.db"); //metti la fonte

        public DbSet<Persona> Persone { get; set; } //vuole il tipo su cui costruire tabelle nel db set
    }

}
