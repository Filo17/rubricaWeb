﻿using System.ComponentModel.DataAnnotations;

namespace Ambrogiani.Filippo._4i.rubrucaWebDb.Models
{
    public class Persona
    {
        [Key] //la primary key deve essere UNA, si deve chiamare Id oppure mettere questa key tra parentesi quadre
        public int? IdPersona { get; set; } //è un ID o anche detto chiave primaria
        public string? Nome { get; set; }
        public string? Cognome { get; set; }
        
    }
}
